package shop.types;

public enum CategoryType {
    FOOD, NON_FOOD
}
