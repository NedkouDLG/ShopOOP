package shop.interfaces;

import shop.classes.Product;

import java.util.List;

public interface StorageInterface {

    void addProduct(Product product);
    //void removeProduct(Product product);

}
