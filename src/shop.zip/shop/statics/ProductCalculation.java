package shop.statics;

public class ProductCalculation {
    public static double foodIncrement;
    public static double nonFoodIncrement;
    public static double discount;
    public static int daysToExpire;

}
